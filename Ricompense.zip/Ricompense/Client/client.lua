ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent('esx:showNotification')
AddEventHandler('esx:showNotification', function(message, type, time)
    ESX.ShowNotification(message)
end)

