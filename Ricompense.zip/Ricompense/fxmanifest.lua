fx_version 'cerulean'
games { 'gta5' }

author 'Ricompense'
description 'Sistema di ricompense fatto da Buongiorno-DEV'
version '1.0.0'

shared_scripts {
    'Shared/*.lua'
}

server_scripts {
    'Server/*.lua'
}

client_scripts {
    'Client/*.lua'
}