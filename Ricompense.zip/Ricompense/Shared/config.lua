Config = {}

Config.ItemCasuali = {
    {nome = "weapon_pistol", quantita = 1},
    {nome = "medikit", quantita = 1},
    {nome = "ammo-9", quantita = 50},
    {nome = "money", minquantita = 1000, maxquantita = 10000}
}

Config.Tempo = 600

Config.Comando = 'ricompensa'

Config.Notifiche = 'okok' -- 'okok' oppure 'esx'

return Config
