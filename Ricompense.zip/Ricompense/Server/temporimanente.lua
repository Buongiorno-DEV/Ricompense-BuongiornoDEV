ESX = exports["es_extended"]:getSharedObject()

local ultimaRicompensa = {}
local intervalloRicompense = Config.Tempo

RegisterCommand(Config.Comando, function(source, args, rawCommand)
    local playerId = source
    local player = ESX.GetPlayerFromId(playerId)
    local tempoAttuale = os.time()
    local tempoDallaUltimaRicompensa = tempoAttuale - (ultimaRicompensa[playerId] or 0)
    local tempoPrimaDellaProssimaRicompensa = intervalloRicompense - tempoDallaUltimaRicompensa

    local minutiRimanenti = math.floor(tempoPrimaDellaProssimaRicompensa / 60)
    local secondiRimanenti = tempoPrimaDellaProssimaRicompensa % 60

    if tempoDallaUltimaRicompensa >= intervalloRicompense then
        ultimaRicompensa[playerId] = tempoAttuale

        if Config.Notifiche == "esx" then
            TriggerClientEvent('esx:showNotification', playerId, string.format("Hai ricevuto la tua ricompensa", 5000, 'success', true))
        elseif Config.Notifiche == "okok" then
            TriggerClientEvent('okokNotify:Alert', source, 'Ricompensa', 'Hai gia ricevuto la tua ricompensa recentemente', 5000, 'error', true)
        end
    else
        if Config.Notifiche == "esx" then
            TriggerClientEvent('esx:showNotification', playerId, string.format("Manca %02d:%02d alla prossima ricompensa", minutiRimanenti, secondiRimanenti), 'error', 5000)
        elseif Config.Notifiche == "okok" then
            TriggerClientEvent('okokNotify:Alert', playerId, 'Ricompensa', string.format("Manca %02d:%02d alla prossima ricompensa", minutiRimanenti, secondiRimanenti), 5000, 'info', true)
        end
    end
end, false)
