local ESX = exports["es_extended"]:getSharedObject()

local function generateRewards()
    local itemCasuale = Config.ItemCasuali[math.random(1, #Config.ItemCasuali)]
    local itemName = itemCasuale.nome
    local itemQuantity = 0

    if itemName == "money" then
        itemQuantity = math.random(itemCasuale.minquantita, itemCasuale.maxquantita)
    else
        itemQuantity = itemCasuale.quantita
    end

    return itemName, itemQuantity
end

local function distributeRewards()
    local players = ESX.GetPlayers()  

    for _, player in ipairs(players) do
        local xPlayer = ESX.GetPlayerFromId(player)

        if xPlayer ~= nil then
            local item, quantita = generateRewards()

            if item == "money" then
                xPlayer.addMoney(quantita)
                if Config.Notifiche == 'okok' then
                    TriggerClientEvent('okokNotify:Alert', player, 'Ricompensa', "Hai ricevuto $" .. quantita, 5000, 'success', true)
                elseif Config.Notifiche == 'esx' then
                    TriggerClientEvent('esx:showNotification', player, "Hai ricevuto $" .. quantita, 'info', 5000)
                end
            else
                xPlayer.addInventoryItem(item, quantita)
                if Config.Notifiche == 'okok' then
                    TriggerClientEvent('okokNotify:Alert', player, 'Ricompensa', "Hai ricevuto " .. quantita .. " " .. item, 5000, 'success', true)
                elseif Config.Notifiche == 'esx' then
                    TriggerClientEvent('esx:showNotification', player, "Hai ricevuto " .. quantita .. " " .. item, 'info', 5000)
                end
            end
        end
    end
end

Citizen.CreateThread(function()
    while true do
        distributeRewards()
        Citizen.Wait(Config.Tempo * 1000)
    end
end)
